#!/usr/bin/env bash
# Roomzin Deployment Script
# Usage: ./deploy.sh --server root@ip --mode [standalone|clustered] [--node-id hostname]
# Example: ./deploy.sh --server root@172.20.0.10 --mode clustered --node-id roomzin-0

set -euo pipefail

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --server) SERVER="$2"; shift 2 ;;
        --mode) MODE="$2"; shift 2 ;;
        --node-id) NODE_ID="$2"; shift 2 ;;
        *) echo "Unknown flag: $1" >&2; exit 1 ;;
    esac
done

# Validate args
[ -z "${SERVER:-}" ] && { echo "Missing --server"; exit 1; }
[ -z "${MODE:-}" ] && { echo "Missing --mode"; exit 1; }
if [ "$MODE" = "clustered" ] && [ -z "${NODE_ID:-}" ]; then
    echo "Clustered mode requires --node-id"
    exit 1
fi

# Remote paths
REMOTE_BASE="/opt/roomzin"
BINARY="roomzin"
CONFIGS_DIR="configs"
CERTS_DIR="certs"
SNAPSHOTS_DIR="snapshots"
SNAPSHOT_FILE="snapshot.tar.zst"
HOSTS_FILE="hosts_entries.txt"

# Validate local files
if [ ! -f "$BINARY" ]; then
    echo "Missing $BINARY"
    exit 1
fi

if [ ! -d "$CONFIGS_DIR" ] || [ ! -f "$CONFIGS_DIR/roomzin.yml" ] || [ ! -f "$CONFIGS_DIR/auth.yml" ]; then
    echo "Missing configs/ files"
    exit 1
fi

if [ "$MODE" = "clustered" ]; then
    if [ ! -f "$HOSTS_FILE" ]; then
        echo "Missing $HOSTS_FILE"
        exit 1
    fi
    if [ ! -f "$CERTS_DIR/ca.pem" ]; then
        echo "Missing $CERTS_DIR/ca.pem (run gen_certs.sh)"
        exit 1
    fi
    NODE_CERT_DIR="$CERTS_DIR/$NODE_ID"
    if [ ! -f "$NODE_CERT_DIR/cert.pem" ] || [ ! -f "$NODE_CERT_DIR/key.pem" ]; then
        echo "Missing certs for $NODE_ID"
        exit 1
    fi
fi

echo "🚀 Deploying to $SERVER in $MODE mode..."

# Detect sudo requirement
SSH_SUDO="sudo"
if [[ "$SERVER" == root@* ]]; then
    SSH_SUDO=""
fi

# Create remote directories
ssh "$SERVER" "$SSH_SUDO mkdir -p $REMOTE_BASE/{bin,configs,certs,snapshots}"

# Copy binary
scp "$BINARY" "$SERVER:$REMOTE_BASE/bin/roomzin"
ssh "$SERVER" "$SSH_SUDO chmod +x $REMOTE_BASE/bin/roomzin"

# Copy configs
scp "$CONFIGS_DIR/roomzin.yml" "$SERVER:$REMOTE_BASE/configs/roomzin.yml"
scp "$CONFIGS_DIR/auth.yml" "$SERVER:$REMOTE_BASE/configs/auth.yml"

# Apply node-id if needed
if [ -n "${NODE_ID:-}" ]; then
    ssh "$SERVER" "$SSH_SUDO sed -i'' -e \"s/^  node_id: .*/  node_id: \\\"$NODE_ID\\\"/\" $REMOTE_BASE/configs/roomzin.yml"
fi

# Cluster certs
if [ "$MODE" = "clustered" ]; then
    scp "$CERTS_DIR/ca.pem" "$SERVER:$REMOTE_BASE/certs/ca.pem"
    scp "$NODE_CERT_DIR/cert.pem" "$SERVER:$REMOTE_BASE/certs/cert.pem"
    scp "$NODE_CERT_DIR/key.pem" "$SERVER:$REMOTE_BASE/certs/key.pem"
fi

# Copy snapshot if available
if [ -f "$SNAPSHOTS_DIR/$SNAPSHOT_FILE" ]; then
    scp "$SNAPSHOTS_DIR/$SNAPSHOT_FILE" "$SERVER:$REMOTE_BASE/snapshots/$SNAPSHOT_FILE"
    echo "📦 Copied snapshot to remote storage"
fi

# Update /etc/hosts (for clustered mode)
if [ "$MODE" = "clustered" ]; then
    scp "$HOSTS_FILE" "$SERVER:/tmp/hosts_entries.txt"
    ssh "$SERVER" "$SSH_SUDO bash -s" <<'EOF'
while read -r line; do
    if ! grep -qF "$line" /etc/hosts; then
        echo "$line" | tee -a /etc/hosts >/dev/null
    fi
done < /tmp/hosts_entries.txt
rm -f /tmp/hosts_entries.txt
EOF
fi

# Run the Roomzin binary in background safely (works even if nohup is missing)
ssh "$SERVER" "$SSH_SUDO bash -c 'setsid $REMOTE_BASE/bin/roomzin run --mode $MODE --config $REMOTE_BASE/configs/roomzin.yml > $REMOTE_BASE/roomzin.log 2>&1 &'"

echo "✅ Deployment complete."
echo "   Logs available at: $REMOTE_BASE/roomzin.log"
