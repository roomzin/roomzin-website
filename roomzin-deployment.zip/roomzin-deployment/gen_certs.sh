#!/bin/bash

# Usage: ./gen_certs.sh hostname1 hostname2 ...
# Generates ca.pem and per-hostname cert/key with CN/SAN.

set -e

CERTS_DIR="certs"
CA_DAYS=3650
CERT_DAYS=365
KEY_BITS=2048

mkdir -p "$CERTS_DIR"

# Generate CA if not exists
if [ ! -f "$CERTS_DIR/ca.pem" ]; then
    openssl genrsa -out "$CERTS_DIR/ca.key" $KEY_BITS
    openssl req -new -x509 -days $CA_DAYS -key "$CERTS_DIR/ca.key" -out "$CERTS_DIR/ca.pem" -subj "/CN=Roomzin CA" -sha256
    echo "Generated CA: $CERTS_DIR/ca.pem"
fi

for HOSTNAME in "$@"; do
    HOST_DIR="$CERTS_DIR/$HOSTNAME"
    mkdir -p "$HOST_DIR"
    
    # Server key
    openssl genrsa -out "$HOST_DIR/key.pem" $KEY_BITS
    
    # CSR with subj
    openssl req -new -key "$HOST_DIR/key.pem" -out "$HOST_DIR/temp.csr" -subj "/CN=$HOSTNAME" -sha256
    
    # Sign with CA, add SAN
    openssl x509 -req -in "$HOST_DIR/temp.csr" -CA "$CERTS_DIR/ca.pem" -CAkey "$CERTS_DIR/ca.key" -CAcreateserial \
        -out "$HOST_DIR/cert.pem" -days $CERT_DAYS -sha256 -extfile <(printf "subjectAltName=DNS:%s" "$HOSTNAME")
    
    rm "$HOST_DIR/temp.csr"
    echo "Generated for $HOSTNAME: $HOST_DIR/cert.pem and key.pem"
done